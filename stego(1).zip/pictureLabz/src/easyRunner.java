

public class easyRunner {

	public static void main(String[] args) {
		easy e = new easy();
	}

}
