
public class Runner {

	public static void main(String[] args) {
		
		/**
		 * Creates a new game logic instance to start the game
		 * Calls the run function which starts the game
		 */
		
		GameLogic gameLogic = new GameLogic();
		
		gameLogic.run();

	}

}
