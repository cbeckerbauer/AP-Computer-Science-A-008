
public class TextAdventureRunner {

	public static void main(String[] args) {
		
		TextAdventureGameLogic newGame = new TextAdventureGameLogic();

	}

}
