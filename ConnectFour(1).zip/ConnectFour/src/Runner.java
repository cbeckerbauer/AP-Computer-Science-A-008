
public class Runner {

	public static void main(String[] args) {
		
		GameLogic gameLogic = new GameLogic();
		
		gameLogic.run();
		
//		int row = gameLogic.getGridRow();
//		int col = gameLogic.getGridCol();
		
//		Grid grid = new Grid(row, col);
//
//		grid.dropPiece(true, (gameLogic.getCol(row, col) - 1));
//		grid.dropPiece(false, 0);
//		grid.dropPiece(true, (gameLogic.getCol(row, col) - 1));
		
//		gamelogic.getRowsAndCols();

	}

}
