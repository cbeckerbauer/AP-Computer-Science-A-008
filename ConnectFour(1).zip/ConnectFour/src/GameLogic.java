import java.util.Scanner;

public class GameLogic {

	private Scanner scan;
	private Grid grid;
	private boolean win;

	public GameLogic() {
		scan = new Scanner(System.in);
		win = false;
	}

	public int getCol(int maxCol) {
		System.out.println("What column do you drop your piece: " + (maxCol));
		String response = scan.nextLine();
		int answer = Integer.parseInt(response) - 1;
		return answer;
	}

	public int getGridRow() {
		System.out.println("What is the max number of row(s) do you want?");
		String response = scan.nextLine();
		int answer = Integer.parseInt(response);
		return answer;
	}

	public int getGridCol() {
		System.out.println("What is the max number of column(s) do you want?");
		String response = scan.nextLine();
		int answer = Integer.parseInt(response);
		return answer;
	}

	public void run() {
		int requestedRow = getGridRow();
		int requestedCol = getGridCol();
		grid = new Grid(requestedRow, requestedCol);
		plays(requestedCol, requestedRow);
	}

	public void plays(int maxCol, int maxRow) {
		int col = 0;
		while (!win) {
			col = getCol(maxCol);
			if (grid.dropPiece(true, col) == true) {
//				checkWin(maxRow, maxCol, col);
//				if (win) {
//					end("X");
//				}
				getComputerPlays(maxCol, col, maxRow);
//				checkWin(maxRow, maxCol, col);
//				if (win) {
//					end("O");
//				}
			}
		}
	}

	public void getComputerPlays(int maxCol, int col, int maxRow) {
		int computerCol = col;
		maxCol = maxCol - 1;
		if (grid.dropPiece(false, computerCol) == false) {
			if (computerCol == maxCol) {
				System.out.println("Max Col");
				if (grid.isItFull(col - 1)) {
					System.out.println("Computer cannot move.");
//					checkWin(maxRow, maxCol, col);
//					if (win) {
//						end("O");
//					}
				} else {
					grid.dropPiece(false, computerCol - 1);
				}
			} else if (computerCol == 0) {
				System.out.println("Zero");
				if (grid.isItFull(col + 1)) {
					System.out.println("Computer cannot move.");
//					checkWin(maxRow, maxCol, col);
//					if (win) {
//						end("O");
//					}
				} else {
					grid.dropPiece(false, computerCol + 1);
				}
			} else if (grid.isItFull(col - 1) && grid.isItFull(col + 1)) {
				System.out.println("Both rows are full");
				for (int i = 0; i < grid.grid.length; i++) {
					if (grid.isItFull(col + i) == false) {
						System.out.println("I moved right");
						grid.dropPiece(false, col + 1);
					} else if (grid.isItFull(col - i) == false) {
						System.out.println("I moved left");
						grid.dropPiece(false, col - 1);
					} else {
						System.out.println("Computer cannot move");
//						checkWin(maxRow, maxCol, col);
//						if (win) {
//							end("O");
//							break;
//						}
					}
				}
			} else if (grid.isItFull(col - 1)) {
				System.out.println("Left Full");
				if (grid.isItFull(col - 1) && grid.isItFull(col)) {
					for (int i = 0; i < grid.grid.length; i++) {
						if (grid.isItFull(col + i) == false) {
							System.out.println("I moved right");
							grid.dropPiece(false, col + 1);
						} else if (grid.isItFull(col - i) == false) {
							System.out.println("I moved left");
							grid.dropPiece(false, col - 1);
						} else {
							System.out.println("Computer cannot move");
//							checkWin(maxRow, maxCol, col);
//							if (win) {
//								end("O");
//								break;
//							}
						}
					}
				} else if (grid.isItFull(col - 1) == false) {
					grid.dropPiece(false, col - 1);
				} else if (grid.isItFull(col + 1) == false) {
					grid.dropPiece(false, col + 1);
				} else {
					grid.dropPiece(false, computerCol + 1);
				}
//				checkWin(maxRow, maxCol, col);
//				if (win) {
//					end("O");
//				}
			} else if (grid.isItFull(col + 1)) {
				System.out.println("Right Full");
				if (grid.isItFull(col + 1) && grid.isItFull(col)) {
					for (int i = 0; i < grid.grid.length; i++) {
						if (grid.isItFull(col + i) == false) {
							System.out.println("I moved right");
							grid.dropPiece(false, col + 1);
						} else if (grid.isItFull(col - i) == false) {
							System.out.println("I moved left");
							grid.dropPiece(false, col - 1);
						} else {
							System.out.println("Computer cannot move");
//							checkWin(maxRow, maxCol, col);
//							if (win) {
//								break;
//							}
						}
					}
				} else if (grid.isItFull(col - 1) == false) {
					grid.dropPiece(false, col - 1);
				} else if (grid.isItFull(col + 1) == false) {
					grid.dropPiece(false, col + 1);
				} else {
					grid.dropPiece(false, computerCol + 1);
				}
			}
		} else {
			System.out.println("Second");
		}
	}

//	public boolean checkWin(int maxRow, int maxCol, int col) {
//		int winCount = 0;
//		int row = 0;
//		int playerCount = 0;
//		int computerCount = 0;
//		String computer = "O";
//		String player = "X";
//		if (maxCol <= 4) {
//			winCount = 3;
//		} else if (maxCol <= 7 && maxCol > 4) {
//			winCount = 4;
//		} else if (maxCol > 7) {
//			winCount = 5;
//		}
//		for (int i = 0; i <= maxCol; i++) {
//			for (int j = 0; j <= maxCol; j++) {
//				for (int q = 0; q <= maxRow; q++) {
//					if (grid.getPiece(q, col) == player) {
//						row = q;
//						break;
//					} else {
//						System.out.println("Not a X here");
//					}
//				}
//				if (grid.getPiece(row, col + i) == player) {
//					playerCount++;
//				}
//				if (grid.getPiece(row, col - i) == player) {
//					playerCount++;
//				}
//				if (row > -1) {
//					if (grid.getPiece(row + j, col) == player) {
//						playerCount++;
//					}
//					if (grid.getPiece(row - j, col) == player) {
//						playerCount++;
//					}
//					if (grid.getPiece(row + j, col + i) == player) {
//						playerCount++;
//					}
//					if (grid.getPiece(row + j, col - i) == player) {
//						playerCount++;
//					}
//					if (grid.getPiece(row - j, col + i) == player) {
//						playerCount++;
//					}
//					if (grid.getPiece(row - j, col - i) == player) {
//						playerCount++;
//					}
//				}
//			}
//		}
//		for (int z = 0; z <= maxCol; z++) {
//			for (int y = 0; y <= maxCol; y++) {
//				for (int x = 0; x <= maxRow; x++) {
//					if (grid.getPiece(x, col) == player) {
//						row = x;
//						break;
//					} else {
//						System.out.println("Not a X here");
//					}
//				}
//				if (grid.getPiece(row, col + z) == player) {
//					playerCount++;
//				}
//				if (grid.getPiece(row, col - z) == player) {
//					playerCount++;
//				}
//				if (row > -1) {
//					if (grid.getPiece(row + y, col) == player) {
//						playerCount++;
//					}
//					if (grid.getPiece(row - y, col) == player) {
//						playerCount++;
//					}
//					if (grid.getPiece(row + y, col + z) == player) {
//						playerCount++;
//					}
//					if (grid.getPiece(row + y, col - z) == player) {
//						playerCount++;
//					}
//					if (grid.getPiece(row - y, col + z) == player) {
//						playerCount++;
//					}
//					if (grid.getPiece(row - y, col - z) == player) {
//						playerCount++;
//					}
//				}
//			}
//		}
//		if (playerCount >= winCount) {
//			win = true;
//		} else {
//			win = false;
//		}
//		return win;
//	}

//	public void end(String piece) {
//		int winComputer = 0;
//		int winPlayer = 0;
//		if (piece == "X") {
//			winPlayer++;
//			System.out.println("Congrats! Would you like to play again?");
//			System.out.println(winPlayer);
//		} else {
//			winComputer++;
//			System.out.println("So sad, you lost? Would you like to play again?");
//			System.out.println(winComputer);
//		}
//	}

}