
public class Coordinate {

}
